======================================================
tsmule: An XAI framework for time series explanation!
======================================================


.. toctree::
   :maxdepth: 2
   
   usage/installation.ipynb
   usage/quick_start.ipynb
   modules/modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
